const express = require('express')
const { check } = require('express-validator')

const app = express()

const { sendMessage } = require('../controllers/chat')
const { verifyToken } = require('../middleware/autentication')
const { validFields } = require('../middleware/valid_fields')

app.post("/chat/send_message", [
        check('message', 'We need a message').not().isEmpty(),
        validFields,
        verifyToken
    ],
    sendMessage)

module.exports = app